<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Événements</title>
    <link rel="stylesheet" href="/gestion_evenements/public/css/style.css">
    <script src="/gestion_evenements/public/js/script.js" defer></script>

</head>
<body>
    <header>
        <h2>Système de Gestion des Événements</h2>
        <hr>
    </header>
    <main>
