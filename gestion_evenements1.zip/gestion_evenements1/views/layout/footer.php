</main>
    <hr>
    <footer>
        <p style="text-align: center;">&copy; <?= date('Y') ?> - Gestion des Événements</p>
    </footer>
</body>
</html>
